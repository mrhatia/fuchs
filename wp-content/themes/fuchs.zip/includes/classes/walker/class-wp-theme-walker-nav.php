<?php
/**
 * Custom walker classes.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package FUCHS Package
 * @since 1.0.0
 */

namespace BaseTheme\Walker;

use \Walker_Nav_Menu;


/**
 * Template Class For Walker menu
 *
 * Template Class
 *
 * @category Walker_Class
 * @package  FUCHS Package
 */
class WP_Theme_Walker_Nav extends \Walker_Nav_Menu {

	/**
	 * Starts the list before the elements are added.
	 *
	 * Adds classes to the unordered list sub-menus.
	 *
	 * @param string $output output variable.
	 * @param number $depth depth or the menu item li.
	 * @param array  $args arguments of the menu item li.
	 *
	 * @return void
	 */
	public function start_lvl( &$output, $depth = 0, $args = array() ) {
		// Depth-dependent classes.
		$indent        = ( $depth > 0 ? str_repeat( "\t", $depth ) : '' ); // code indent.
		$display_depth = ( $depth + 1 ); // because it counts the first submenu as 0.
		$classes       = array(
			'sub-menu',
			( $display_depth % 2 ? 'menu-odd' : 'menu-even' ),
			( $display_depth >= 2 ? 'sub-sub-menu' : '' ),
			'menu-depth-' . $display_depth,
		);
		$class_names   = implode( ' ', $classes );

		// Build HTML for output.
		$output .= "\n" . $indent . '<ul class="' . $class_names . '">' . "\n";
	}

	/**
	 * Start the element output.
	 *
	 * Adds main/sub-classes to the list items and links.
	 *
	 * @param string $output output variable.
	 * @param string $item the item inside ul.
	 * @param number $depth depth or the menu item ul.
	 * @param array  $args arguments of the menu item ul.
	 * @param number $id its just a number.
	 *
	 * @return void
	 */
	public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
		global $wp_query;
		$indent = ( $depth > 0 ? str_repeat( "\t", $depth ) : '' ); // code indent.

		// Depth-dependent classes.
		$depth_classes     = array(
			( 0 === $depth ? 'main-menu-item' : 'sub-menu-item' ),
			( 2 >= $depth ? 'sub-sub-menu-item' : '' ),
			( $depth % 2 ? 'menu-item-odd' : 'menu-item-even' ),
			'menu-item-depth-' . $depth,
		);
		$depth_class_names = esc_attr( implode( ' ', $depth_classes ) );

		// Passed classes.
		$classes = empty( $item->classes ) ? array() : (array) $item->classes;
		// @codingStandardsIgnoreStart
		$class_names = esc_attr( implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) ) );

		// Build HTML.
		$output .= $indent . '<li id="nav-menu-item-' . $item->ID . '" class="' . $depth_class_names . ' ' . $class_names . '">';

		// Link attributes.
		$attributes  = ! empty( $item->attr_title ) ? ' title="' . esc_attr( $item->attr_title ) . '"' : '';
		$attributes .= ! empty( $item->target ) ? ' target="' . esc_attr( $item->target ) . '"' : '';
		$attributes .= ! empty( $item->xfn ) ? ' rel="' . esc_attr( $item->xfn ) . '"' : '';
		$attributes .= ! empty( $item->url ) ? ' href="' . esc_attr( $item->url ) . '"' : '';
		$attributes .= ' class="menu-link ' . ( $depth > 0 ? 'sub-menu-link' : 'main-menu-link' ) . '"';
		if( ''===$item->url || '#'===$item->url ) {
			$item_schema='%1$s<span%2$s>%3$s%4$s%5$s</span>%6$s';
		}else{
			$item_schema='%1$s<a%2$s>%3$s%4$s%5$s</a>%6$s';
		}
		// Build HTML output and pass through the proper filter.
		$item_output = sprintf(
			$item_schema,
			$args->before,
			$attributes,
			$args->link_before,
			apply_filters( 'the_title', $item->title, $item->ID ),
			$args->link_after,
			$args->after
		);

		$output     .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
		// @codingStandardsIgnoreEnd
	}
}

